# Project
- `frontend/` - HTML, CSS, JS
- `backend/` - Node.js Express API
